Currency Solutions
Front-end Developer role test task
==================================

This test pack includes two files:
- README (this file)
- CS_FED_Test.psd

We ask you to make HTML 5 compatible layout of the given page.
Please provide a small description of technologies and software you used to complete the task.
Please send us ZIP archive with the result.

Mandatory requirements:
- Use Twitter Bootstrap
- Make it responsive
- Use React or Angular
- Use WebPack, Grunt or Gulp

Optional features:
- Use LESS
- Use CSS sprites
- Download data to show from JSON files provided on page load